package com.cg.paymentwalletapplication.service.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletapplication.dao.IPaymentDao;
import com.cg.paymentwalletapplication.dao.PaymentDaoImpl;
import com.cg.paymentwalletapplication.dto.Wallet;
import com.cg.paymentwalletapplication.exception.PaymentException;
import com.cg.paymentwalletapplication.service.IPaymentService;
import com.cg.paymentwalletapplication.service.PaymentServiceImpl;


public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();
		@Test
		public void CheckForZeroDeposittest() {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("7095804719");
			dao.createAccount(wallet);
			condition=service.deposit("7095804719", 0.0);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidDepositAmount() {
			boolean condition=false;
			Wallet wallet=new Wallet();
			wallet.setUserId("7095804719");
			dao.createAccount(wallet);
			condition=service.deposit("7095804719", 500);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("absdy5t5q6");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priya@gmail.com");
			service.validateDetails(wallet);
		}
		
		@Test
		public void CheckForValidNameTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priya@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("709580");
			wallet.setEmailId("priya@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidPhoneNumberTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priya@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}
		
		@Test (expected=PaymentException.class)
		public void CheckForInvalidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("4g53jkbf");
			boolean condition=service.validateDetails(wallet);
			assertFalse(condition);
		}
		
		@Test
		public void CheckForValidEmailTest() throws PaymentException {
			Wallet wallet=new Wallet();
			wallet.setName("Priyanka");
			wallet.setPhNumber("7095804719");
			wallet.setEmailId("priya@gmail.com");
			boolean condition=service.validateDetails(wallet);
			assertTrue(condition);
		}

}
